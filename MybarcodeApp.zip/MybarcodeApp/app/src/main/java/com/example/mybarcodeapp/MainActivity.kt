package com.example.mybarcodeapp


import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        scanManualInput.requestFocus()

        val editText = findViewById<View>(R.id.scanManualInput) as EditText
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT)


    }


    private val barcode = StringBuffer()

    override fun dispatchKeyEvent(event: KeyEvent?): Boolean {

        if (event?.action == KeyEvent.ACTION_DOWN) {
            val pressedKey = event.unicodeChar.toChar()

            barcode.append(pressedKey)
//            changeOverlayProduct(barcode.toString())
            Toast.makeText(this, "$barcode", Toast.LENGTH_SHORT).show()
        }
        if (event?.action == KeyEvent.ACTION_DOWN && event.keyCode == KeyEvent.KEYCODE_ENTER) {
            Toast.makeText(baseContext, barcode.toString(), Toast.LENGTH_SHORT).show()
            barcode.delete(0, barcode.length)
            Toast.makeText(this, "$barcode", Toast.LENGTH_SHORT).show()
        }

        return super.dispatchKeyEvent(event)
    }
}